package com.example.junaid.hackagriculture;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RiceActivity extends AppCompatActivity {
Button button8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rice);
        button8 = (Button) findViewById(R.id.button8);
        button8.setVisibility(View.VISIBLE);
        button8.setBackgroundColor(Color.TRANSPARENT);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(), RiceDetailsActivity.class);
                startActivity(intent);
            }
        });
    }
}
