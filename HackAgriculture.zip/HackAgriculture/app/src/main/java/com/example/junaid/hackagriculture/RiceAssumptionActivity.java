package com.example.junaid.hackagriculture;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RiceAssumptionActivity extends AppCompatActivity {
Button button17;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rice_assumption);
        button17 = (Button) findViewById(R.id.button17);
        button17.setVisibility(View.VISIBLE);
        button17.setBackgroundColor(Color.TRANSPARENT);
        button17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(), RiceAgentActivity.class);
                startActivity(intent);
            }
        });
    }
}
