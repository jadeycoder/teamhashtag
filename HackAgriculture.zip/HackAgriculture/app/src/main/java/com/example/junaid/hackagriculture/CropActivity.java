package com.example.junaid.hackagriculture;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class CropActivity extends AppCompatActivity {
Button button18,button20;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop);
        button18 = (Button) findViewById(R.id.button18);
        button18.setVisibility(View.VISIBLE);
        button18.setBackgroundColor(Color.TRANSPARENT);
        button18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(), CropActivity.class);
                startActivity(intent);
            }
        });
        button20 = (Button) findViewById(R.id.button20);
        button20.setVisibility(View.VISIBLE);
        button20.setBackgroundColor(Color.TRANSPARENT);
        button20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(), MainWindowActivity.class);
                startActivity(intent);
            }
        });
    }
}
