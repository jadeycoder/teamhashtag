package com.example.junaid.hackagriculture;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainWindowActivity extends AppCompatActivity {
    Button button,button2,button3,button4,button5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_window); button = (Button) findViewById(R.id.button);
        button.setVisibility(View.VISIBLE);
        button.setBackgroundColor(Color.TRANSPARENT);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(), RiceActivity.class);
                startActivity(intent);
            }
        });
        button4 = (Button) findViewById(R.id.button4);
        button4.setVisibility(View.VISIBLE);
        button4.setBackgroundColor(Color.TRANSPARENT);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(), InformationActivity.class);
                startActivity(intent);
            }
        });
        button5 = (Button) findViewById(R.id.button5);
        button5.setVisibility(View.VISIBLE);
        button5.setBackgroundColor(Color.TRANSPARENT);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(), CropActivity.class);
                startActivity(intent);
            }
        });
        button3 = (Button) findViewById(R.id.button3);
        button3.setVisibility(View.VISIBLE);
        button3.setBackgroundColor(Color.TRANSPARENT);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(), EmergencyActivity.class);
                startActivity(intent);
            }
        });
        button2 = (Button) findViewById(R.id.button2);
        button2.setVisibility(View.VISIBLE);
        button2.setBackgroundColor(Color.TRANSPARENT);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(), QuestionsActivity.class);
                startActivity(intent);
            }
        });


    }

}
