package com.example.junaid.hackagriculture;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RIceAreaActivity extends AppCompatActivity {
Button button12;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rice_area);
        button12 = (Button) findViewById(R.id.button12);
        button12.setVisibility(View.VISIBLE);
        button12.setBackgroundColor(Color.TRANSPARENT);
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(),RiceAssumptionActivity.class);
                startActivity(intent);
            }
        });
    }
}
